<?php

class ImovelBean {

    
    function cadastrarImovel($imovel){
        
      return true;
        
    }
    
}
