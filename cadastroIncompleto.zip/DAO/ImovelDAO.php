<?php

class ImovelDAO {
    
    function cadastrarImovel(){
        
    }
    
}
